import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { RouterModule, Routes } from '@angular/router';
import { MainDashboardComponent } from './main-dashboard/main-dashboard.component';
@NgModule({
  imports: [
    CommonModule,RouterModule
  ],
  declarations: [HomeComponent, MainDashboardComponent]
})
export class HomeModule { }
