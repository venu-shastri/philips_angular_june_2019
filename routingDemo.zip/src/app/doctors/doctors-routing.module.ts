import { NgModule } from "@angular/core";
import { RouterModule, Routes } from '@angular/router';
import { DocDashboardComponent } from "./doc-dashboard/doc-dashboard.component";


const dcotorsModuleRoutes:Routes=[
    {path:'',component:DocDashboardComponent}
    
    
];

@NgModule({
    imports:[RouterModule.forChild(dcotorsModuleRoutes)],
    exports:[RouterModule]
})
export class DoctorsRoutingModule{

}