import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doc-dashboard',
  templateUrl: './doc-dashboard.component.html',
  styleUrls: ['./doc-dashboard.component.css']
})
export class DocDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
