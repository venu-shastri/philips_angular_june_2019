import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DocDashboardComponent } from './doc-dashboard/doc-dashboard.component';
import { DoctorsRoutingModule } from './doctors-routing.module';

@NgModule({
  imports: [
    CommonModule,DoctorsRoutingModule
  ],
  declarations: [DocDashboardComponent]
})
export class DoctorsModule { }
