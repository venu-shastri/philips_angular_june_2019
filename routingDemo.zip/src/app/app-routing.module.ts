import { NgModule } from "@angular/core";
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from "./home/home/home.component";
import { LoginComponent } from "./accounts/login/login.component";
import { SignupComponent } from "./accounts/signup/signup.component";
import { MainDashboardComponent } from "./home/main-dashboard/main-dashboard.component";

const appRoutes:Routes=[
    { path:'home',component:HomeComponent,children:[
        {path:'login',component:LoginComponent},
        {path:'signup',component:SignupComponent}
    ]},
    {path:'' , redirectTo:'home',pathMatch:'full'},
    {path:'mainDashboard',
           component:MainDashboardComponent,
           children:[
               {path:'hospitals',loadChildren:'./hospitals/hospitals.module#HospitalsModule'},
               {path:'doctors',loadChildren:'./doctors/doctors.module#DoctorsModule'}
           ]}
];

@NgModule({

    imports:[RouterModule.forRoot(appRoutes)],
    exports:[RouterModule]

})
export class AppRoutingModule{

}