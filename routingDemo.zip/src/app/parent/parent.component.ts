import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject'


@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  modelState=new BehaviorSubject<string>("");
  constructor(cdRef:ChangeDetectorRef) {

    //cdRef.detach();

   }

  ngOnInit() {
    //this.modelState={name:'tom',email:'tom@pic.com'};
  }
  changeModelState(newEmail){
  
this.modelState.next(newEmail);

  }

}
