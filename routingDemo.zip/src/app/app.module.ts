import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import {BrowserModule} from '@angular/platform-browser'
import {HomeModule} from './home/home.module'
import { AccountsModule } from './accounts/accounts.module';
import { AppComponent } from './app.component';

import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';

@NgModule({
  imports: [
    CommonModule,BrowserModule,HomeModule,AccountsModule,AppRoutingModule
  ],
  declarations: [ParentComponent, ChildComponent, AppComponent],
  bootstrap:[AppComponent]
  
  
})
export class AppModule { }
