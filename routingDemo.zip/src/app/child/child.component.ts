import { Component, OnInit,Input, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css'],
  changeDetection:ChangeDetectionStrategy.OnPush
})
export class ChildComponent implements OnInit {


  @Input()
  modelState:Observable<any>;

  newEmail:string;
  
  constructor(public cdRef:ChangeDetectorRef) { }

  ngOnInit() {

    this.modelState.subscribe((data)=>{
      console.log(data);
        this.newEmail=data;
        this.cdRef.markForCheck();
    });
  }
 
  refresh(){

}
}
