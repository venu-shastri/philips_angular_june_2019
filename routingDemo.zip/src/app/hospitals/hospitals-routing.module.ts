import { NgModule } from "@angular/core";
import { RouterModule, Routes } from '@angular/router';
import { HospitalDashboardComponent } from "./hospital-dashboard/hospital-dashboard.component";



const hospitalsModuleRoutes:Routes=[
    {path:'',component:HospitalDashboardComponent}
    
    
];

@NgModule({
    imports:[RouterModule.forChild(hospitalsModuleRoutes)],
    exports:[RouterModule]
})
export class HospitalsRoutingModule{

}