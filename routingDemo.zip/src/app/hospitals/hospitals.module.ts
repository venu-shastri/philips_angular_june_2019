import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HospitalDashboardComponent } from './hospital-dashboard/hospital-dashboard.component';
import { HospitalsRoutingModule } from './hospitals-routing.module';

@NgModule({
  imports: [
    CommonModule,HospitalsRoutingModule
  ],
  declarations: [HospitalDashboardComponent]
})
export class HospitalsModule { }
