import { NgModule } from "@angular/core";
import { TableComponent } from "./components/table.component";
import { THeadComponent } from "./components/thead.component";
import { TBodyComponent } from "./components/tbody.component";

@NgModule({
    declarations:[TableComponent,THeadComponent,TBodyComponent],
    exports:[TableComponent,THeadComponent,TBodyComponent]
})
export class CustomTableModule{

}