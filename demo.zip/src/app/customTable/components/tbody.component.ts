import { Component } from "@angular/core";

@Component({
    selector:'tbody-comp',
    templateUrl:'./tbody.component.html'
})
export class TBodyComponent{

}