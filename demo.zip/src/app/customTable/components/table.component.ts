import { Component } from "@angular/core";

@Component({
    selector:'table-comp',
    templateUrl:'./table.component.html'
})
export class TableComponent{

}