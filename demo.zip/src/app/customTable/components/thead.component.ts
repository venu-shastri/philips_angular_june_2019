import { Component } from "@angular/core";

@Component({
    selector:'thead-comp',
    templateUrl:'./thead.component.html'
})
export class THeadComponent{

}