import {NgModule} from '@angular/core'
import {GreeterComponent} from './greeter.component'
import { HeaderComponent } from './header.component';
import { FooterComponent } from './footer.component';
import { MainContentComponent } from './mainContent.component';

 
@NgModule({

    declarations:[HeaderComponent,FooterComponent,MainContentComponent],
    exports:[HeaderComponent,FooterComponent,MainContentComponent]

})
export class LayoutModule{

}

