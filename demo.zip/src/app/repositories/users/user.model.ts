export class UserModel{

    constructor(
        public userName:string,
        public password:string,
        public email:string){

    }
}