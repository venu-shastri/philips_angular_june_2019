import { UserModel } from "./user.model";
import { UserRepositoryService } from "./userRepository.service";
import { ILogger } from "../../services/logger.service";
import { Injectable } from "@angular/core";

@Injectable()
export class LocalStorageUserRepositoryService extends UserRepositoryService {

    private users:Array<UserModel>=new Array<UserModel>();

    constructor(public logger:ILogger){
        super();
    }

    createNewUser(user:UserModel){
        this.users.push(user);
        this.dump();
        
    }

    getAllUsers():Array<UserModel>{
        return this.users;
    }
    
    dump(){

        this.users.forEach((user)=>{
        this.logger.write(`${user.userName} ${user.password} ${user.email}`); 
        });

    }


}