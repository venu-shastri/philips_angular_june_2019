import {UserModel} from './user.model';
export abstract class UserRepositoryService{
    abstract createNewUser(user:UserModel);

    abstract getAllUsers():Array<UserModel>;
}