import {Component} from '@angular/core'

@Component({
    template:'<h1>Hello  From Header Component</h1>',
    selector:'header-comp'
})
export class HeaderComponent{

    //logic
}