import {Component} from '@angular/core'

@Component({
    template:'<h1>Hello From Component</h1>',
    selector:'main-content-comp'
})
export class MainContentComponent{

    //logic
}