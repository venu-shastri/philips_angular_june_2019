import { NgModule } from "@angular/core";
import { SearchBarComponent } from "./components/searchBar.component";
import { SearchPanelComponent } from "./components/searchPanel.component";
import { SearchResultComponent } from "./components/searchResult.component";
import {CommonModule} from "@angular/common"
@NgModule({
    declarations:[SearchBarComponent,SearchPanelComponent,SearchResultComponent],
    exports:[SearchPanelComponent],
    imports:[CommonModule]
})
export class UserSerachModule{

}