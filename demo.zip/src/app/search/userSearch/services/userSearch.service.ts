import { UserRepositoryService } from "../../../repositories/users/userRepository.service";
import { UserModel } from "../../../repositories/users/user.model";
import { Injectable } from "@angular/core";
import { ILogger } from "../../../services/logger.service";

@Injectable()
export class UserSearchService{


    constructor(public repo:UserRepositoryService,public logger:ILogger){}
    search(key:string):Array<UserModel>{

        this.logger.write(`searchKey ${key}`);
        let searchResult=new Array<UserModel>();
        for(let i=0;i<this.repo.getAllUsers().length;i++){
            if(this.repo.getAllUsers()[i].userName.startsWith(key)){
                    searchResult.push(this.repo.getAllUsers()[i]);
            }
        }
        return searchResult;


    }

}