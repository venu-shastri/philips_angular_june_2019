import { Component, ViewChild } from "@angular/core";
import { UserSearchService } from "../services/userSearch.service";
import { ILogger } from "../../../services/logger.service";
import { UserModel } from "../../../repositories/users/user.model";
import { SearchBarComponent } from "./searchBar.component";

@Component({
    selector:'search-panel-comp',
    templateUrl:'./searchPanel.component.html',
    providers:[{provide:UserSearchService,useClass:UserSearchService}],
    viewProviders:[]
})
export class SearchPanelComponent{

    @ViewChild(SearchBarComponent)
    searcBarRef:SearchBarComponent;
    
    searchResult=new Array<UserModel>();
   constructor(public searchService:UserSearchService,public logger:ILogger){
    
   }
   onSearchKeyChanged(key)
   {
       this.logger.write("Search key " + key);
       this.searchResult= this.searchService.search(key);
   }

}