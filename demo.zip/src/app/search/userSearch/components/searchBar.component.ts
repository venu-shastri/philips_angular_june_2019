import { Component, EventEmitter, Output } from "@angular/core";
import { ILogger } from "../../../services/logger.service";

@Component({
    selector:'search-bar-comp',
    templateUrl:'./searchBar.component.html'
})
export class SearchBarComponent{

    constructor(public logger:ILogger){

    }
    @Output()
    searchKeyChangedEvent=new EventEmitter<string>();

    search(key){

        //Notify Parent Component
        this.logger.write("SearcBar Search Key "+key);
        this.searchKeyChangedEvent.emit(key);
    }

}