import { Component, Input } from "@angular/core";
import { UserModel } from "../../../repositories/users/user.model";

@Component({
    selector:'search-result-comp',
    templateUrl:'./searchResult.component.html'
})
export class SearchResultComponent{

    @Input()
    searchResult:Array<UserModel>;

}