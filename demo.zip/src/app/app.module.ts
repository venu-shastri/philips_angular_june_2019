import {NgModule} from '@angular/core'
import {GreeterComponent} from './greeter.component'
import {BrowserModule} from '@angular/platform-browser'
import { LayoutModule } from './layout.module';
import { HeaderComponent } from './header.component';
import { FooterComponent } from './footer.component';
import { MainContentComponent } from './mainContent.component';
import { RootComponent } from './root.component';
import { AccountsModule } from './accounts/accounts.module';
import { ILogger } from './services/logger.service';
import { ConsoleLoggerService } from './services/consoleLogger.service';
import { UserRepositoryService } from './repositories/users/userRepository.service';
import { LocalStorageUserRepositoryService } from './repositories/users/localStorageUserRepository.service';

import { UserSerachModule } from './search/userSearch/userSearch.module';
import { CustomTableModule } from './customTable/customTable.module';
import { InteractionModule } from './interaction/interaction.module';
 
@NgModule({

    declarations:[GreeterComponent,RootComponent],
    bootstrap:[RootComponent],
    imports:[BrowserModule,LayoutModule,AccountsModule,UserSerachModule,CustomTableModule,InteractionModule],
    providers:[
        {provide:"ILogger",useClass:ConsoleLoggerService},
        {provide:ILogger,useClass:ConsoleLoggerService},
        {provide:"ILoggerInstance",useValue:new ConsoleLoggerService()},
        {provide:"httpAddress",useValue:"http://pic.com/users/service"},
        {provide:UserRepositoryService,useClass:LocalStorageUserRepositoryService}

    ]
    
})
export class AppModule{

}

