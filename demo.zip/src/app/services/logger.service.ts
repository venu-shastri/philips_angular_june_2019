export abstract class ILogger{
    abstract write(msg:string):void
}