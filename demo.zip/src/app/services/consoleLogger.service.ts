import {ILogger} from './logger.service'
export class ConsoleLoggerService extends ILogger{
    write(msg:string){
        console.log(msg);
    }
}