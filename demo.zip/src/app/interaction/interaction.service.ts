import {Subject} from 'rxjs/Subject'

export class InteractionService{

    //subject
    private dataSubject=new Subject<string>();
    //observable
    dataObservable=this.dataSubject.asObservable();

    notifySubject(data){
        //load data into stream
            this.dataSubject.next(data);
    }


}