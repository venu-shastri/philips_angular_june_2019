import { Component } from "@angular/core";
import { InteractionService } from "../interaction.service";

@Component({
    selector:'source-comp',
    templateUrl:'./source.component.html'
})
export class SourceComponent{
    constructor(public service:InteractionService){}
    onInputChanged(data)
    {
        this.service.notifySubject(data);
    }
}