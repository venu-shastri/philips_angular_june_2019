import { Component, OnInit, OnDestroy } from "@angular/core";
import { InteractionService } from "../interaction.service";
import { Subscription } from "rxjs/Subscription";

@Component({
    selector:'target-comp',
    templateUrl:'./target.component.html'
})
export class TargetComponent implements OnInit,OnDestroy{

    subScriptionRef:Subscription;
    constructor(public service:InteractionService){}

    ngOnInit(){
         this.subScriptionRef=   this.service.dataObservable.subscribe((data)=>{

                this.inputdata=data;
            });
    }

    ngOnDestroy(){
        this.subScriptionRef.unsubscribe();
    }
    inputdata:string;
}