import { NgModule } from "@angular/core";
import { SourceComponent } from "./components/source.component";
import { TargetComponent } from "./components/target.component";
import { InteractionService } from "./interaction.service";

@NgModule({
    declarations:[SourceComponent,TargetComponent],
    providers:[{provide:InteractionService,useClass:InteractionService}],
    exports:[SourceComponent,TargetComponent]
})
export class InteractionModule{


}