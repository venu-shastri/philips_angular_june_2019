import {UserModel} from '../../repositories/users/user.model'
import { UserRepositoryService } from '../../repositories/users/userRepository.service';
import {Inject, Injectable} from '@angular/core'
import { ILogger } from '../../services/logger.service';

@Injectable()
export class AccountService{

    constructor( 
         public repo:UserRepositoryService,
         public logger:ILogger ){

    }
    register(user:UserModel){
            this.repo.createNewUser(user);
    }
	authenticate(userName:string,password:string):boolean{
        let isValiduser:boolean=false;
        this.repo.getAllUsers().forEach((user)=>{
                if(user.userName===userName && user.password===password){
                    isValiduser=true;
                }

        });
        this.logger.write(isValiduser.toString());
            return isValiduser;
    }
	changePassword(userName:string,oldPassword:string,newPassword:string){

    }

}