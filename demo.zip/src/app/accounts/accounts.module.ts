import { NgModule } from "@angular/core";
import { LoginComponent } from "./components/login/login.component";
import { SignupComponent } from "./components/signup/signup.component";
import {FormsModule} from "@angular/forms"
import { AccountService } from "./services/accounts.service";
@NgModule({
    declarations:[LoginComponent,SignupComponent],
    imports:[FormsModule],
    exports:[LoginComponent,SignupComponent],
    providers:[{provide:AccountService,useClass:AccountService}]
})
export class AccountsModule{

}