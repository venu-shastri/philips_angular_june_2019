import { Component } from "@angular/core";
import { AccountService } from "../../services/accounts.service";
import { ILogger } from "../../../services/logger.service";

@Component({
    selector:'login-comp',
    templateUrl:'./login.component.html'
})
export class LoginComponent{

    constructor(public service:AccountService,public logger:ILogger){

    }
    userName:string="";
    password:string="";
    statusMessage:string="Invalid User Name and Password";
    login(){
        this.logger.write(`${this.userName} ${this.password}`);
           if(this.service.authenticate(this.userName,this.password)){
               this.statusMessage="Valid Credentials ....Redirecting....";
           } 
    }
    onUserNameEdit(value){
        this.userName=value;
    }
    onPasswordEdit(value){
        this.password=value;
    }

}