import { Component, Inject } from "@angular/core";
import { ILogger } from "../../../services/logger.service";
import { AccountService } from "../../services/accounts.service";
import { UserModel } from "../../../repositories/users/user.model";

@Component({
    selector:'signup-comp',
    templateUrl:'./signup.component.html'
})
export class SignupComponent{

    constructor(@Inject('ILogger') public logger:ILogger,
    public service:AccountService){

    }
    userName:string="";
    password:string="";
    email:string="";
    
    signup(){
      this.service.register(new UserModel(this.userName,this.password,this.email));
    }
    clear(){
       this. userName="";
        this.password="";
       this. email="";
    }

}