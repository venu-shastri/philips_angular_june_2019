import {Component} from '@angular/core'

@Component({
    template:'<h1>Hello From Component</h1>',
    selector:'greeter-comp'
})
export class GreeterComponent{

    //logic
}