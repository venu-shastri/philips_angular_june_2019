import { Component, OnInit, OnDestroy } from "@angular/core";

@Component({
    selector:'root-comp',
    templateUrl:'./root.component.html'
})
export class RootComponent implements OnInit,OnDestroy{

    ngOnInit(){
//Called Once
    }
    ngOnDestroy(){
//Called Once
    }
    
}